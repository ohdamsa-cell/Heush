import {onCall,HttpsError} from "firebase-functions/v2/https";
import {onValueCreated} from "firebase-functions/v2/database";
import {initializeApp} from "firebase-admin/app";
import {getDatabase} from "firebase-admin/database";
import {randomBytes,randomInt} from "node:crypto";
initializeApp();
const db=getDatabase();
const roles=["superadmin","admin","staff"];
function requireAdmin(req:any){if(!req.auth)throw new HttpsError("unauthenticated","Login diperlukan.");const role=req.auth.token.role;if(!roles.includes(role))throw new HttpsError("permission-denied","Akses admin diperlukan.");return req.auth.uid;}
export const createOrder=onCall({region:"asia-southeast1",enforceAppCheck:true},async(req)=>{
 const p=req.data||{};const game=String(p.game||"");const productId=String(p.productId||"");const qty=Number(p.quantity);
 if(!Number.isSafeInteger(qty)||qty<1||qty>10000)throw new HttpsError("invalid-argument","Jumlah tidak valid.");
 if(!["Growtopia","Growblox","Roblox","Free Fire","Mobile Legends"].includes(game))throw new HttpsError("invalid-argument","Game tidak valid.");
 if(!["BUY","SELL"].includes(p.mode))throw new HttpsError("invalid-argument","Mode transaksi tidak valid.");
 if(!p.account||typeof p.account!=="object")throw new HttpsError("invalid-argument","Data akun wajib diisi.");
 const prodRef=db.ref(`products/${productId}`);const prodSnap=await prodRef.get();if(!prodSnap.exists())throw new HttpsError("not-found","Produk tidak ditemukan.");
 const prod=prodSnap.val();if(prod.game!==game||!prod.active)throw new HttpsError("failed-precondition","Produk tidak aktif.");
 if(p.mode==="BUY"&&Number(prod.stock)<qty)throw new HttpsError("failed-precondition","Stok tidak cukup.");
 const price=Number(prod.price);if(!Number.isSafeInteger(price)||price<0)throw new HttpsError("failed-precondition","Harga produk tidak valid.");
 const total=price*qty;if(!Number.isSafeInteger(total))throw new HttpsError("invalid-argument","Total di luar batas.");
 const id=`VIN-${Date.now().toString().slice(-6)}${randomInt(10,99)}`;const secret=randomBytes(24).toString("hex");const now=Date.now();
 const order={id,secretHash:secret,uid:req.auth?.uid||null,game,mode:p.mode,account:p.account,product:prod.name,productId,quantity:qty,unitPrice:price,total,paymentMethod:String(p.paymentMethod||"QRIS"),status:"PENDING_PROOF",createdAt:now,expiresAt:now+15*60*1000};
 // Atomic stock reservation and order write; no browser-supplied price is used.
 const result=await prodRef.transaction((current)=>{if(!current||!current.active)return; if(p.mode==="BUY"){if(Number(current.stock)<qty)return;current.stock=Number(current.stock)-qty;}return current;});
 if(!result.committed)throw new HttpsError("aborted","Stok berubah atau habis. Silakan coba lagi.");
 try{await db.ref(`orders/${id}`).set(order);await db.ref(`orderSecrets/${id}`).set({hash:secret});}
 catch(e){if(p.mode==="BUY")await prodRef.transaction((c)=>{if(c)c.stock=Number(c.stock||0)+qty;return c;});throw e;}
 return {invoiceId:id,accessToken:secret,total,expiresAt:order.expiresAt,instructions:"Lakukan pembayaran sesuai instruksi toko, lalu upload bukti pembayaran."};
});
export const adminUpdateOrder=onCall({region:"asia-southeast1",enforceAppCheck:true},async(req)=>{
 const uid=requireAdmin(req);const {orderId,status,reason}=req.data||{};const allowed=["WAITING_ACC","PROCESSING","COMPLETED","REJECTED","CANCELLED","EXPIRED"];
 if(!allowed.includes(status))throw new HttpsError("invalid-argument","Status tidak diizinkan.");
 const r=db.ref(`orders/${orderId}`);const s=await r.get();if(!s.exists())throw new HttpsError("not-found","Invoice tidak ditemukan.");
 const old=s.val();const transitions:any={PENDING_PROOF:["WAITING_ACC","CANCELLED","EXPIRED"],WAITING_ACC:["PROCESSING","REJECTED","CANCELLED"],REJECTED:["WAITING_ACC","CANCELLED"],PROCESSING:["COMPLETED"],COMPLETED:[],CANCELLED:[],EXPIRED:[]};
 if(!transitions[old.status]?.includes(status))throw new HttpsError("failed-precondition","Perubahan status tidak valid.");
 if(status==="REJECTED"&&!String(reason||"").trim())throw new HttpsError("invalid-argument","Alasan penolakan wajib diisi.");
 await r.update({status,rejectReason:status==="REJECTED"?String(reason).slice(0,500):null,updatedAt:Date.now(),updatedBy:uid});
 await db.ref(`transactionLogs/${Date.now()}-${uid}`).set({orderId,from:old.status,to:status,uid,at:Date.now(),reason:reason||null});
 // SELL lock stock is credited only after deposit proof is accepted (admin advances to PROCESSING).
 if(old.mode==="SELL"&&status==="PROCESSING"){const sr=db.ref(`stock/${old.game}/${old.productId}`);await sr.transaction(v=>Number(v||0)+Number(old.quantity));}
 return {ok:true};
});
export const setProduct=onCall({region:"asia-southeast1",enforceAppCheck:true},async(req)=>{const uid=requireAdmin(req);const p=req.data||{};if(!p.id||!p.game||!p.name||!Number.isSafeInteger(Number(p.price))||Number(p.price)<0||!Number.isSafeInteger(Number(p.stock))||Number(p.stock)<0)throw new HttpsError("invalid-argument","Data produk tidak valid.");await db.ref(`products/${p.id}`).set({...p,updatedAt:Date.now(),updatedBy:uid});return{ok:true};});
