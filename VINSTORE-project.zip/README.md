# VINSTORE — Gaming Marketplace

Project React + TypeScript + Tailwind + Firebase. Desain dan alur UX dibangun ulang dengan identitas VINSTORE. File referensi `web.html` menunjukkan satu halaman toko DAYSHOP dengan mode beli/jual Growtopia, metode Donation Box/Display Box/Direct Trade, invoice lookup, admin login, pengaturan rate/stok, paket game, testimoni dan upload aset. Implementasi ini mengembangkan alur tersebut ke struktur modular.

## Penting: status kesiapan
UI dapat dijalankan lokal. Backend belum aktif sampai pemilik mengisi Firebase project, deploy rules/functions, mengatur role admin, serta mengunggah QRIS/rekening asli. UI tidak mengarang transaksi maupun mengklaim bukti upload sebagai pembayaran valid. Checkout menampilkan pengingat integrasi sampai callable backend dihubungkan. Jangan gunakan untuk menerima uang sebelum checklist keamanan selesai.

## Jalankan frontend
1. Install Node.js 20+.
2. `npm install`
3. Salin `.env.example` menjadi `.env` dan isi Firebase Web App config.
4. `npm run dev` lalu buka URL Vite.
5. `npm run build` untuk produksi.

## Firebase
1. Buat project Firebase dan aktifkan Realtime Database (region dekat Indonesia), Authentication > Email/Password, Storage, dan Functions.
2. Buat Web App, salin config ke `.env`.
3. Install Firebase CLI: `npm i -g firebase-tools`, lalu `firebase login` dan `firebase use --add`.
4. `cd functions && npm install && npm run build && cd ..`
5. Deploy `firebase deploy --only database,storage,functions`.
6. Aktifkan App Check dan sesuaikan enforcement untuk environment produksi.
7. Seed katalog awal secara manual melalui admin tool/backend tepercaya; jangan izinkan client menulis produk/stok.

## Admin pertama (tanpa password hardcode)
- Buat user melalui Firebase Authentication > Add user.
- Ambil UID user tersebut.
- Jalankan skrip tepercaya dari lingkungan admin yang memiliki Firebase Admin SDK, bukan browser:
```ts
import { initializeApp, cert } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
initializeApp({credential:cert(require("./service-account.json"))});
await getAuth().setCustomUserClaims("UID_USER", {role:"superadmin"});
```
- Sign out/in ulang agar token memuat custom claim. Jangan commit service-account.json.
- Role yang didukung: `superadmin`, `admin`, `staff`. Implementasikan pembatasan granular staff sebelum memberi akses produksi.

## Struktur database yang disarankan
- `products/{productId}`: game, name, price (integer rupiah), stock (integer), active, unit.
- `orders/{invoiceId}`: uid, mode, account, productId, quantity, unitPrice, total, paymentMethod, status, proofPath, timestamps.
- `orderSecrets/{invoiceId}`: akses invoice rahasia (server-only).
- `publicConfig`: nama toko, tagline, depositWorld, jam operasional, nomor CS dan pengumuman.
- `paymentMethods/{method}`: enabled, label, accountName, accountNumber, qrisStoragePath.
- `stock/{game}/{productId}`: stok terpisah bila model inventori mengharuskannya.
- `rates/{game}/{item}`: harga beli/jual dan stok.
- `packages/{game}/{packageId}`: paket game.
- `categories/{categoryId}`, `users/{uid}`, `admins/{uid}`, `testimonials/{id}`, `assets/{id}`, `notifications/{id}`, `transactionLogs/{id}`.

## Status pesanan
`PENDING_PROOF` → `WAITING_ACC` → `PROCESSING` → `COMPLETED`; pembayaran ditolak memakai `REJECTED`, pengguna/admin dapat membatalkan `CANCELLED`, dan invoice melewati batas waktu menjadi `EXPIRED`. Transisi dijaga Cloud Function. Upload bukti hanya memindahkan status ke `WAITING_ACC`, bukan menandai pembayaran lunas.

## Pembayaran
- Unggah QRIS resmi dari dashboard Firebase Storage atau panel admin tepercaya.
- Masukkan rekening DANA/GoPay/SeaBank milik toko ke `paymentMethods`.
- Jangan memasukkan nomor contoh atau QRIS dummy ke produksi.
- Pembayaran otomatis memerlukan payment gateway resmi + webhook signature verification. Screenshot saja tidak dapat membuktikan settlement.
- Countdown invoice 15 menit perlu scheduled function untuk menandai expired dan melepas reservasi stok.

## Sebelum produksi — wajib dilengkapi
- Implementasikan callable `lookupInvoice` dengan invoice ID + secret token yang diverifikasi hash server-side; jangan membuka pencarian berdasarkan ID saja.
- Ganti `createOrder` placeholder frontend dengan `httpsCallable(functions, "createOrder")` dan simpan access token hanya di browser pemesan.
- Buat endpoint upload proof callable/Storage metadata validation dan jangan menyimpan URL publik permanen; gunakan Storage path + signed/authorized reads.
- Perbaiki flow jual lock: simpan kuantitas deposit, bukti deposit, rekening payout, dan hanya kredit inventory setelah verifikasi admin.
- Tambahkan payout approval, validasi rekening, rate beli/jual terpisah, kode unik opsional, dan idempotency key.
- Tambahkan transaction outbox agar pembuatan order + reservasi stok + log benar-benar atomik. Kode contoh melakukan reservasi stok lalu rollback best-effort jika write order gagal; untuk skala produksi gunakan desain single RTDB transaction pada parent inventory+order atau Cloud SQL/Firestore transaction.
- Pastikan role staff permissions granular; audit log immutable; backup terjadwal; App Check; rate limiting; CAPTCHA bila perlu.
- Tambahkan admin dashboard CRUD lengkap, laporan profit akuntansi, moderasi testimoni verified-only, carousel promo, notifikasi real transaction dan WhatsApp link.
- Jangan publikasikan data pribadi atau transaksi tanpa consent. Jangan buat riwayat transaksi palsu.

## Catatan referensi
File `web.html` memiliki title DAYSHOP, tombol Cek Invoice/Admin, katalog lima game, carousel promo, alur beli/jual lock, form akun per game, pembayaran DANA/GoPay/SeaBank, invoice lookup, dashboard admin dengan tab orders/rates/packages/testimonials/assets, upload aset lokal/Netlify dan Firebase RTDB root lama `yegashop`. Project ini tidak menggunakan kredensial lama atau identitas toko lama.
