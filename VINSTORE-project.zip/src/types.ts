export type Game="Growtopia"|"Growblox"|"Roblox"|"Free Fire"|"Mobile Legends";
export type OrderStatus="PENDING_PROOF"|"WAITING_ACC"|"PROCESSING"|"COMPLETED"|"REJECTED"|"CANCELLED"|"EXPIRED";
export type Product={id:string;game:Game;name:string;description:string;price:number;stock:number;unit:string;active:boolean;image?:string};
export type Order={id:string;secret:string;game:Game;mode:"BUY"|"SELL";account:Record<string,string>;product:string;quantity:number;unitPrice:number;total:number;paymentMethod:string;status:OrderStatus;createdAt:number;expiresAt:number;proofUrl?:string;rejectReason?:string};
