import type {Product,Game} from "./types";
export const games: {name:Game;subtitle:string;symbol:string;accent:string}[]=[
{name:"Growtopia",subtitle:"Diamond Lock & Blue Gem Lock",symbol:"✦",accent:"#06B6D4"},
{name:"Growblox",subtitle:"World Lock, DL & BGL",symbol:"◈",accent:"#8B5CF6"},
{name:"Roblox",subtitle:"Robux & gamepass delivery",symbol:"⬡",accent:"#F97316"},
{name:"Free Fire",subtitle:"Top up diamond cepat",symbol:"◆",accent:"#F43F5E"},
{name:"Mobile Legends",subtitle:"Diamond & Weekly Pass",symbol:"⚔",accent:"#3B82F6"}];
export const initialProducts:Product[]=[
...(["DL","BGL"].map((n,i)=>({id:"gt-"+n,game:"Growtopia" as Game,name:n==="DL"?"Diamond Lock":"Blue Gem Lock",description:"Growtopia currency",price:i?45000:5000,stock:100,unit:n,active:true}))),
...(["WL","DL","BGL"].map((n,i)=>({id:"gb-"+n,game:"Growblox" as Game,name:n,description:"Growblox currency",price:[1000,5000,45000][i],stock:100,unit:n,active:true}))),
...([{id:"rb-80",game:"Roblox" as Game,name:"80 Robux",description:"Paket Robux",price:16000,stock:999,unit:"paket",active:true},{id:"ff-100",game:"Free Fire" as Game,name:"100 Diamond",description:"Paket diamond",price:15000,stock:999,unit:"paket",active:true},{id:"ml-86",game:"Mobile Legends" as Game,name:"86 Diamond",description:"Paket diamond",price:22000,stock:999,unit:"paket",active:true}])];
