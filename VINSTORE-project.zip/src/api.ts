import {ref,get,onValue,runTransaction,push,set,update} from "firebase/database";
import {httpsCallable} from "firebase/functions";
import {db,auth} from "./firebase";
import type {Order,Product} from "./types";
import {initialProducts} from "./catalog";
// Functions are deliberately required for price/stock-authoritative order creation.
export function watchProducts(cb:(p:Product[])=>void){if(!db){cb(initialProducts);return()=>{};}return onValue(ref(db,"products"),s=>cb(s.exists()?Object.values(s.val()) as Product[]:initialProducts));}
export function watchPublicConfig(cb:(v:any)=>void){if(!db){cb({storeName:"VINSTORE",depositWorld:"VINSTORE"});return()=>{};}return onValue(ref(db,"publicConfig"),s=>cb(s.val()||{}));}
export async function createOrder(payload:any){if(!auth?.currentUser)throw new Error("Isi Firebase config dan aktifkan autentikasi terlebih dahulu.");throw new Error("Cloud Function createOrder belum di-deploy. Lihat functions/src/index.ts dan README.");}
export async function uploadProof(orderId:string,file:File){if(!auth?.currentUser||!db)throw new Error("Firebase belum dikonfigurasi.");const {getStorage,ref:sr,uploadBytes,getDownloadURL}=await import("firebase/storage");const st=getStorage();const path=`paymentProofs/${auth.currentUser.uid}/${orderId}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;const snap=await uploadBytes(sr(st,path),file,{contentType:file.type});const url=await getDownloadURL(snap.ref);await update(ref(db,`orders/${orderId}`),{proofUrl:url,status:"WAITING_ACC"});return url;}
export function watchOrder(orderId:string,cb:(v:any)=>void){if(!db){cb(null);return()=>{};}return onValue(ref(db,`orders/${orderId}`),s=>cb(s.val()));}
